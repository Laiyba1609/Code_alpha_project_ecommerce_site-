import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { CartProvider } from "@/components/CartProvider";
import Navbar from "@/components/Navbar";
import { getCurrentUser } from "@/lib/auth";

export const metadata: Metadata = {
  title: "ChocoLuxe — Premium Chocolate & Gift Hampers",
  description:
    "Shop the world's most famous chocolate brands and luxury gift hampers. Sweetness delivered worldwide.",
};

export const dynamic = "force-dynamic";

export default async function RootLayout({ children }: { children: ReactNode }) {
  const user = await getCurrentUser();
  const userProp = user ? { name: user.name, email: user.email } : null;

  return (
    <html lang="en">
      <body className="min-h-screen bg-[#faf6ef] text-stone-900 antialiased">
        <CartProvider>
          <Navbar user={userProp} />
          <main>{children}</main>
          <footer className="border-t border-stone-200 bg-[#2b0f0a] py-10 text-center text-amber-100/70">
            <p className="text-sm">
              🍫 ChocoLuxe — the world&apos;s finest chocolates &amp; gift hampers.
            </p>
            <p className="mt-1 text-xs">Lindt · Ferrero · Godiva · Toblerone · Cadbury &amp; more</p>
          </footer>
        </CartProvider>
      </body>
    </html>
  );
}

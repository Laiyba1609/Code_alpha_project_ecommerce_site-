import Link from "next/link";
import { db } from "@/db";
import { products, type Product } from "@/db/schema";
import { asc, desc, sql } from "drizzle-orm";
import ProductGrid from "@/components/ProductGrid";

export const dynamic = "force-dynamic";

async function getProducts(): Promise<Product[]> {
  const rows = await db
    .select()
    .from(products)
    .orderBy(desc(products.featured), asc(products.name));
  return rows;
}

async function getFeatured(): Promise<Product[]> {
  return db
    .select()
    .from(products)
    .where(sql`${products.featured} = true`)
    .limit(4);
}

export default async function HomePage() {
  const [allProducts, featured] = await Promise.all([getProducts(), getFeatured()]);

  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden bg-[#2b0f0a]">
        <div className="absolute inset-0">
          <video
            className="h-full w-full object-cover opacity-45"
            autoPlay
            muted
            loop
            playsInline
            preload="auto"
            poster="/images/hero.jpg"
            aria-hidden="true"
          >
            <source
              src="https://videos.pexels.com/video-files/11186313/11186313-hd_1920_1080_30fps.mp4"
              type="video/mp4"
            />
          </video>
          <div className="absolute inset-0 bg-gradient-to-r from-[#2b0f0a] via-[#2b0f0a]/80 to-transparent" />
        </div>
        <div className="relative mx-auto flex max-w-6xl flex-col justify-center px-4 py-24 sm:py-32">
          <p className="mb-3 text-sm font-semibold uppercase tracking-[0.2em] text-amber-400">
            The world&apos;s finest chocolates
          </p>
          <h1 className="max-w-xl text-4xl font-extrabold leading-tight text-amber-50 sm:text-5xl">
            Sweeten every moment with premium chocolate &amp; gift hampers
          </h1>
          <p className="mt-4 max-w-md text-amber-100/80">
            Discover iconic brands from Switzerland to Japan — Lindt, Ferrero Rocher,
            Godiva, Toblerone &amp; more — plus curated hampers for every celebration.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              href="#shop"
              className="rounded-full bg-amber-400 px-7 py-3 text-sm font-bold text-stone-900 transition-colors hover:bg-amber-300"
            >
              Shop Now
            </Link>
            <Link
              href="/register"
              className="rounded-full border border-amber-200/50 px-7 py-3 text-sm font-semibold text-amber-100 transition-colors hover:bg-amber-400/10"
            >
              Create an account
            </Link>
          </div>
        </div>
      </section>

      {/* Featured brands */}
      <section className="mx-auto max-w-6xl px-4 py-12">
        <div className="mb-6 flex items-end justify-between">
          <div>
            <h2 className="text-2xl font-extrabold text-stone-900">Featured Favourites</h2>
            <p className="text-sm text-stone-500">Hand-picked bestsellers loved worldwide</p>
          </div>
          <Link href="#shop" className="text-sm font-semibold text-amber-700 hover:underline">
            View all →
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {featured.map((p) => (
            <FeaturedCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* Shop */}
      <section id="shop" className="mx-auto max-w-6xl px-4 pb-20">
        <div className="mb-6">
          <h2 className="text-2xl font-extrabold text-stone-900">The Chocolate Collection</h2>
          <p className="text-sm text-stone-500">
            Famous brands &amp; gift hampers — every piece is pure indulgence.
          </p>
        </div>
        <ProductGrid products={allProducts} />
      </section>
    </>
  );
}

function FeaturedCard({ product }: { product: Product }) {
  return (
    <Link
      href={`/products/${product.id}`}
      className="group overflow-hidden rounded-2xl border border-stone-200 bg-white shadow-sm transition-shadow hover:shadow-lg"
    >
      <div className="aspect-[4/3] overflow-hidden bg-stone-100">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={product.image}
          alt={product.name}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
      </div>
      <div className="p-3">
        <p className="text-[11px] font-semibold uppercase tracking-wider text-amber-700">
          {product.brand}
        </p>
        <p className="mt-0.5 line-clamp-1 text-sm font-semibold text-stone-900">{product.name}</p>
      </div>
    </Link>
  );
}

import Link from "next/link";
import { notFound } from "next/navigation";
import { and, asc, eq, ne } from "drizzle-orm";
import { db } from "@/db";
import { products, type Product } from "@/db/schema";
import { formatCents } from "@/lib/cart";
import AddToCartButton from "@/components/AddToCartButton";

export const dynamic = "force-dynamic";

async function getProduct(id: number) {
  const [product] = await db.select().from(products).where(eq(products.id, id));
  return product ?? null;
}

async function getRelated(current: Product): Promise<Product[]> {
  return db
    .select()
    .from(products)
    .where(and(eq(products.category, current.category), ne(products.id, current.id)))
    .orderBy(asc(products.name))
    .limit(4);
}

export default async function ProductPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const productId = Number(id);
  if (!Number.isInteger(productId)) notFound();

  const product = await getProduct(productId);
  if (!product) notFound();

  const related = await getRelated(product);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <nav className="mb-6 text-sm text-stone-500">
        <Link href="/" className="hover:text-amber-700">Home</Link>
        <span className="mx-2">/</span>
        <span>{product.name}</span>
      </nav>

      <div className="grid gap-10 lg:grid-cols-2">
        <div className="overflow-hidden rounded-3xl border border-stone-200 bg-white shadow-sm">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={product.image} alt={product.name} className="aspect-square w-full object-cover" />
        </div>

        <div className="flex flex-col">
          <div className="flex items-center gap-2">
            <span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-bold uppercase tracking-wider text-amber-800">
              {product.brand}
            </span>
            <span className="text-xs text-stone-400">Made in {product.country || "—"}</span>
          </div>

          <h1 className="mt-3 text-3xl font-extrabold text-stone-900">{product.name}</h1>

          <div className="mt-3 text-3xl font-extrabold text-amber-800">
            {formatCents(product.priceCents)}
          </div>

          <p className="mt-4 leading-relaxed text-stone-600">{product.description}</p>

          <div className="mt-4 flex items-center gap-3">
            <span
              className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold ${
                product.stock > 0 ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
              }`}
            >
              <span
                className={`h-2 w-2 rounded-full ${product.stock > 0 ? "bg-green-500" : "bg-red-500"}`}
              />
              {product.stock > 0 ? `${product.stock} in stock` : "Sold out"}
            </span>
            <span className="text-xs text-stone-400">{product.category === "hamper" ? "Gift Hamper" : "Chocolate"}</span>
          </div>

          <div className="mt-8">
            {product.stock > 0 ? (
              <AddToCartButton
                label="Add to Cart"
                product={{
                  productId: product.id,
                  name: product.name,
                  brand: product.brand,
                  priceCents: product.priceCents,
                  image: product.image,
                }}
              />
            ) : (
              <button disabled className="w-full rounded-full bg-stone-300 px-5 py-2.5 text-sm font-semibold text-stone-500">
                Sold out
              </button>
            )}
          </div>

          <p className="mt-4 text-xs text-stone-400">
            Free delivery over $50 · Gift wrapping available · Worldwide shipping
          </p>
        </div>
      </div>

      {related.length > 0 && (
        <section className="mt-16">
          <h2 className="mb-6 text-2xl font-extrabold text-stone-900">You may also love</h2>
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            {related.map((p) => (
              <Link
                key={p.id}
                href={`/products/${p.id}`}
                className="group overflow-hidden rounded-2xl border border-stone-200 bg-white shadow-sm transition-shadow hover:shadow-lg"
              >
                <div className="aspect-[4/3] overflow-hidden bg-stone-100">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={p.image}
                    alt={p.name}
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                </div>
                <div className="p-3">
                  <p className="text-[11px] font-semibold uppercase tracking-wider text-amber-700">
                    {p.brand}
                  </p>
                  <p className="line-clamp-1 text-sm font-semibold text-stone-900">{p.name}</p>
                  <p className="mt-1 text-sm font-bold text-amber-800">{formatCents(p.priceCents)}</p>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

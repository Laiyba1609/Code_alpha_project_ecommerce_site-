import Link from "next/link";
import { asc, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { orderItems, orders } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { formatCents } from "@/lib/cart";

export const dynamic = "force-dynamic";

export default async function OrdersPage() {
  const user = await getCurrentUser();

  if (!user) {
    return (
      <div className="mx-auto max-w-xl px-4 py-24 text-center">
        <div className="mb-4 text-6xl">📦</div>
        <h1 className="text-2xl font-extrabold text-stone-900">Your Orders</h1>
        <p className="mt-2 text-stone-600">Please login to view your order history.</p>
        <div className="mt-6 flex justify-center gap-3">
          <Link href="/login" className="rounded-full bg-amber-700 px-6 py-2.5 text-sm font-semibold text-white hover:bg-amber-600">
            Login
          </Link>
          <Link href="/register" className="rounded-full border border-stone-300 px-6 py-2.5 text-sm font-semibold text-stone-700 hover:bg-stone-100">
            Register
          </Link>
        </div>
      </div>
    );
  }

  const userOrders = await db
    .select()
    .from(orders)
    .where(eq(orders.userId, user.id))
    .orderBy(desc(orders.createdAt));

  if (userOrders.length === 0) {
    return (
      <div className="mx-auto max-w-xl px-4 py-24 text-center">
        <div className="mb-4 text-6xl">🍫</div>
        <h1 className="text-2xl font-extrabold text-stone-900">No orders yet</h1>
        <p className="mt-2 text-stone-600">When you place an order, it will show up here.</p>
        <Link href="/" className="mt-6 inline-block rounded-full bg-amber-700 px-6 py-2.5 text-sm font-semibold text-white hover:bg-amber-600">
          Start shopping
        </Link>
      </div>
    );
  }

  const itemsByOrder = await Promise.all(
    userOrders.map(async (o) => {
      const items = await db
        .select()
        .from(orderItems)
        .where(eq(orderItems.orderId, o.id))
        .orderBy(asc(orderItems.id));
      return { order: o, items };
    })
  );

  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <h1 className="mb-8 text-3xl font-extrabold text-stone-900">Your Orders</h1>
      <div className="space-y-5">
        {itemsByOrder.map(({ order, items }) => (
          <div key={order.id} className="rounded-2xl border border-stone-200 bg-white p-5 shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-stone-100 pb-3">
              <div>
                <p className="font-bold text-stone-900">Order #{order.id}</p>
                <p className="text-xs text-stone-500">
                  {new Date(order.createdAt).toLocaleString()}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <span className="rounded-full bg-green-100 px-3 py-1 text-xs font-bold text-green-700">
                  {order.status}
                </span>
                <span className="font-bold text-amber-800">{formatCents(order.totalCents)}</span>
              </div>
            </div>
            <ul className="mt-3 space-y-2 text-sm">
              {items.map((item) => (
                <li key={item.id} className="flex justify-between gap-3">
                  <span className="text-stone-700">
                    {item.quantity} × {item.name}
                  </span>
                  <span className="font-medium text-stone-900">
                    {formatCents(item.priceCents * item.quantity)}
                  </span>
                </li>
              ))}
            </ul>
            <p className="mt-3 text-xs text-stone-400">Deliver to: {order.address}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

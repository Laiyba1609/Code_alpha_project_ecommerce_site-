import { NextResponse } from "next/server";
import { inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { orderItems, orders, products } from "@/db/schema";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const session = await getSession();
    const body = await req.json();

    const customerName = String(body.customerName || "").trim();
    const email = String(body.email || "").trim().toLowerCase();
    const address = String(body.address || "").trim();
    const items: { productId: number; quantity: number }[] = Array.isArray(body.items)
      ? body.items
      : [];

    if (!customerName || !email || !address) {
      return NextResponse.json({ error: "Please fill in all shipping details." }, { status: 400 });
    }
    if (items.length === 0) {
      return NextResponse.json({ error: "Your cart is empty." }, { status: 400 });
    }

    const ids = items.map((i) => Number(i.productId));
    if (ids.some((id) => !Number.isInteger(id))) {
      return NextResponse.json({ error: "Invalid cart items." }, { status: 400 });
    }

    const productRows = await db.select().from(products).where(inArray(products.id, ids));
    const byId = new Map(productRows.map((p) => [p.id, p]));

    let totalCents = 0;
    const orderLines = [];

    for (const item of items) {
      const product = byId.get(item.productId);
      if (!product) {
        return NextResponse.json(
          { error: `A product in your cart is no longer available.` },
          { status: 400 }
        );
      }
      const quantity = Number(item.quantity);
      if (!Number.isInteger(quantity) || quantity <= 0) {
        return NextResponse.json({ error: "Invalid quantity." }, { status: 400 });
      }
      if (product.stock < quantity) {
        return NextResponse.json(
          { error: `Only ${product.stock} left of ${product.name}.` },
          { status: 400 }
        );
      }
      totalCents += product.priceCents * quantity;
      orderLines.push({ product, quantity });
    }

    const [order] = await db
      .insert(orders)
      .values({
        userId: session?.userId ?? null,
        customerName,
        email,
        address,
        totalCents,
        status: "confirmed",
      })
      .returning();

    for (const line of orderLines) {
      await db.insert(orderItems).values({
        orderId: order.id,
        productId: line.product.id,
        name: line.product.name,
        priceCents: line.product.priceCents,
        quantity: line.quantity,
      });
      await db
        .update(products)
        .set({ stock: sql`${products.stock} - ${line.quantity}` })
        .where(sql`${products.id} = ${line.product.id}`);
    }

    return NextResponse.json({
      order: { id: order.id, totalCents: order.totalCents, status: order.status },
    });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Something went wrong placing your order." }, { status: 500 });
  }
}

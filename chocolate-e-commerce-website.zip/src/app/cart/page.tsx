"use client";

import { useMemo, useState, type FormEvent } from "react";
import Link from "next/link";
import { useCart } from "@/components/CartProvider";
import { cartSubtotal, formatCents, type CartItem } from "@/lib/cart";

export default function CartPage() {
  const { items, setQuantity, removeItem, clearCart } = useCart();
  const subtotal = useMemo(() => cartSubtotal(items), [items]);
  const shipping = items.length > 0 ? (subtotal >= 5000 ? 0 : 499) : 0;
  const total = subtotal + shipping;

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [order, setOrder] = useState<{ id: number; total: number } | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName: name,
          email,
          address,
          items: items.map((i) => ({ productId: i.productId, quantity: i.quantity })),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to place order");
      setOrder({ id: data.order.id, total: data.order.totalCents });
      clearCart();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setSubmitting(false);
    }
  }

  if (order) {
    return (
      <div className="mx-auto max-w-xl px-4 py-24 text-center">
        <div className="mx-auto mb-6 grid h-20 w-20 place-items-center rounded-full bg-green-100 text-4xl">
          🎉
        </div>
        <h1 className="text-3xl font-extrabold text-stone-900">Order confirmed!</h1>
        <p className="mt-3 text-stone-600">
          Thank you for your order. Your chocolate is on its way.
        </p>
        <p className="mt-2 text-sm text-stone-500">
          Order <span className="font-bold">#{order.id}</span> ·{" "}
          <span className="font-bold">{formatCents(order.total)}</span>
        </p>
        <div className="mt-8 flex justify-center gap-3">
          <Link href="/" className="rounded-full bg-amber-700 px-6 py-2.5 text-sm font-semibold text-white hover:bg-amber-600">
            Continue shopping
          </Link>
          <Link href="/orders" className="rounded-full border border-stone-300 px-6 py-2.5 text-sm font-semibold text-stone-700 hover:bg-stone-100">
            View orders
          </Link>
        </div>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-xl px-4 py-24 text-center">
        <div className="mb-4 text-6xl">🛒</div>
        <h1 className="text-2xl font-extrabold text-stone-900">Your cart is empty</h1>
        <p className="mt-2 text-stone-600">Looks like you haven&apos;t added any chocolate yet.</p>
        <Link href="/" className="mt-6 inline-block rounded-full bg-amber-700 px-6 py-2.5 text-sm font-semibold text-white hover:bg-amber-600">
          Browse chocolates
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="mb-8 text-3xl font-extrabold text-stone-900">Shopping Cart</h1>

      <div className="grid gap-8 lg:grid-cols-[1fr_360px]">
        {/* Items */}
        <div className="space-y-4">
          {items.map((item: CartItem) => (
            <div
              key={item.productId}
              className="flex flex-col gap-4 rounded-2xl border border-stone-200 bg-white p-4 sm:flex-row"
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={item.image}
                alt={item.name}
                className="h-28 w-full rounded-xl object-cover sm:w-28"
              />
              <div className="flex flex-1 flex-col">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wider text-amber-700">
                      {item.brand}
                    </p>
                    <Link
                      href={`/products/${item.productId}`}
                      className="font-semibold text-stone-900 hover:text-amber-800"
                    >
                      {item.name}
                    </Link>
                  </div>
                  <button
                    onClick={() => removeItem(item.productId)}
                    className="text-sm text-stone-400 hover:text-red-600"
                    aria-label="Remove"
                  >
                    ✕
                  </button>
                </div>
                <div className="mt-auto flex items-center justify-between pt-3">
                  <div className="flex items-center rounded-full border border-stone-300">
                    <button
                      onClick={() => setQuantity(item.productId, item.quantity - 1)}
                      className="px-3 py-1 text-stone-500 hover:text-stone-900"
                    >
                      −
                    </button>
                    <span className="w-8 text-center text-sm font-semibold">{item.quantity}</span>
                    <button
                      onClick={() => setQuantity(item.productId, item.quantity + 1)}
                      className="px-3 py-1 text-stone-500 hover:text-stone-900"
                    >
                      +
                    </button>
                  </div>
                  <span className="font-bold text-stone-900">
                    {formatCents(item.priceCents * item.quantity)}
                  </span>
                </div>
              </div>
            </div>
          ))}

          <div className="pt-2">
            <Link href="/" className="text-sm font-semibold text-amber-700 hover:underline">
              ← Continue shopping
            </Link>
          </div>
        </div>

        {/* Checkout */}
        <div className="h-fit rounded-2xl border border-stone-200 bg-white p-6 shadow-sm">
          <h2 className="text-lg font-bold text-stone-900">Checkout</h2>

          <div className="mt-4 space-y-2 border-b border-stone-100 pb-4 text-sm">
            <div className="flex justify-between text-stone-600">
              <span>Subtotal</span>
              <span className="font-medium">{formatCents(subtotal)}</span>
            </div>
            <div className="flex justify-between text-stone-600">
              <span>Shipping</span>
              <span className="font-medium">{shipping === 0 ? "Free" : formatCents(shipping)}</span>
            </div>
            <div className="flex justify-between pt-1 text-base font-bold text-stone-900">
              <span>Total</span>
              <span>{formatCents(total)}</span>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="mt-4 space-y-3">
            <input
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Full name"
              className="w-full rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm outline-none focus:border-amber-500"
            />
            <input
              required
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email address"
              className="w-full rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm outline-none focus:border-amber-500"
            />
            <textarea
              required
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Shipping address"
              rows={3}
              className="w-full rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm outline-none focus:border-amber-500"
            />
            {error && <p className="text-sm font-medium text-red-600">{error}</p>}
            <button
              disabled={submitting}
              className="w-full rounded-full bg-amber-700 py-3 text-sm font-bold text-white transition-colors hover:bg-amber-600 disabled:opacity-60"
            >
              {submitting ? "Placing order…" : "Place Order 🍫"}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

"use client";

import Link from "next/link";
import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Login failed");
      router.refresh();
      router.push("/");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto flex max-w-md flex-col px-4 py-16">
      <div className="mb-6 text-center">
        <div className="text-5xl">🍫</div>
        <h1 className="mt-3 text-3xl font-extrabold text-stone-900">Welcome back</h1>
        <p className="mt-1 text-stone-500">Login to view your orders &amp; checkout faster</p>
      </div>

      <form
        onSubmit={handleSubmit}
        className="rounded-3xl border border-stone-200 bg-white p-8 shadow-sm"
      >
        <div className="space-y-4">
          <div>
            <label className="mb-1 block text-sm font-semibold text-stone-700">Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm outline-none focus:border-amber-500"
              placeholder="you@example.com"
            />
          </div>
          <div>
            <label className="mb-1 block text-sm font-semibold text-stone-700">Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm outline-none focus:border-amber-500"
              placeholder="••••••••"
            />
          </div>
          {error && <p className="text-sm font-medium text-red-600">{error}</p>}
          <button
            disabled={loading}
            className="w-full rounded-full bg-amber-700 py-3 text-sm font-bold text-white transition-colors hover:bg-amber-600 disabled:opacity-60"
          >
            {loading ? "Logging in…" : "Login"}
          </button>
        </div>
      </form>

      <p className="mt-6 text-center text-sm text-stone-600">
        Don&apos;t have an account?{" "}
        <Link href="/register" className="font-semibold text-amber-700 hover:underline">
          Create one
        </Link>
      </p>
    </div>
  );
}

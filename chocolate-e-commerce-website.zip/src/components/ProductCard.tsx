import Link from "next/link";
import type { Product } from "@/db/schema";
import { formatCents } from "@/lib/cart";
import AddToCartButton from "./AddToCartButton";

export default function ProductCard({ product }: { product: Product }) {
  return (
    <div className="group flex flex-col overflow-hidden rounded-2xl border border-stone-200 bg-white shadow-sm transition-shadow hover:shadow-xl">
      <Link href={`/products/${product.id}`} className="relative block aspect-[4/3] overflow-hidden bg-stone-100">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={product.image}
          alt={product.name}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        {product.featured && (
          <span className="absolute left-3 top-3 rounded-full bg-amber-500 px-2.5 py-1 text-xs font-bold text-white shadow">
            ★ Bestseller
          </span>
        )}
        {product.stock <= 0 && (
          <span className="absolute inset-0 grid place-items-center bg-stone-900/50 text-sm font-bold text-white">
            Sold out
          </span>
        )}
      </Link>

      <div className="flex flex-1 flex-col p-4">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-amber-700">
            {product.brand}
          </span>
          <span className="text-[11px] text-stone-400">{product.country}</span>
        </div>
        <Link
          href={`/products/${product.id}`}
          className="mt-1 line-clamp-2 text-sm font-semibold text-stone-900 hover:text-amber-800"
        >
          {product.name}
        </Link>
        <p className="mt-1 line-clamp-2 text-xs text-stone-500">{product.description}</p>

        <div className="mt-auto pt-4">
          <div className="mb-3 text-lg font-extrabold text-stone-900">
            {formatCents(product.priceCents)}
          </div>
          <AddToCartButton
            product={{
              productId: product.id,
              name: product.name,
              brand: product.brand,
              priceCents: product.priceCents,
              image: product.image,
            }}
          />
        </div>
      </div>
    </div>
  );
}

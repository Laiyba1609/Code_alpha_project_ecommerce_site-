"use client";

import { useState } from "react";
import { useCart } from "./CartProvider";
import type { CartItem } from "@/lib/cart";

type Props = {
  product: Omit<CartItem, "quantity">;
  label?: string;
};

export default function AddToCartButton({ product, label = "Add to Cart" }: Props) {
  const { addItem } = useCart();
  const [added, setAdded] = useState(false);

  function handleAdd() {
    addItem(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 1400);
  }

  return (
    <button
      onClick={handleAdd}
      className={
        added
          ? "inline-flex w-full items-center justify-center gap-2 rounded-full bg-green-600 px-5 py-2.5 text-sm font-semibold text-white transition-colors"
          : "inline-flex w-full items-center justify-center gap-2 rounded-full bg-amber-700 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-amber-600"
      }
    >
      {added ? (
        <>
          <span>✓</span> Added!
        </>
      ) : (
        <>
          <span>🛒</span> {label}
        </>
      )}
    </button>
  );
}

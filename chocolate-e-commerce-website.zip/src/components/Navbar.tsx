"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useCart } from "./CartProvider";
import { cartCount } from "@/lib/cart";

type NavbarProps = {
  user: { name: string; email: string } | null;
};

export default function Navbar({ user }: NavbarProps) {
  const { items } = useCart();
  const count = cartCount(items);
  const pathname = usePathname();
  const router = useRouter();

  async function handleLogout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.refresh();
    router.push("/");
  }

  const linkCls = (href: string) =>
    `text-sm font-medium transition-colors hover:text-amber-200 ${
      pathname === href ? "text-amber-300" : "text-amber-100/80"
    }`;

  return (
    <header className="sticky top-0 z-50 border-b border-stone-200 bg-[#2b0f0a]/95 text-amber-50 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
        <Link href="/" className="flex items-center gap-2">
          <span className="text-2xl">🍫</span>
          <span className="text-lg font-extrabold tracking-tight text-amber-100">
            Choco<span className="text-amber-400">Luxe</span>
          </span>
        </Link>

        <nav className="flex items-center gap-5">
          <Link href="/" className={linkCls("/")}>
            Shop
          </Link>
          <Link href="/cart" className={linkCls("/cart")}>
            Cart
            {count > 0 && (
              <span className="ml-1.5 inline-flex min-w-[1.35rem] items-center justify-center rounded-full bg-amber-400 px-1.5 py-0.5 text-xs font-bold text-stone-900">
                {count}
              </span>
            )}
          </Link>
          {user ? (
            <>
              <Link href="/orders" className={linkCls("/orders")}>
                Orders
              </Link>
              <button
                onClick={handleLogout}
                className="rounded-full border border-amber-400/60 px-4 py-1.5 text-sm font-medium text-amber-100 transition-colors hover:bg-amber-400 hover:text-stone-900"
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <Link href="/login" className={linkCls("/login")}>
                Login
              </Link>
              <Link
                href="/register"
                className="rounded-full bg-amber-400 px-4 py-1.5 text-sm font-semibold text-stone-900 transition-colors hover:bg-amber-300"
              >
                Sign up
              </Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}

"use client";

import { useMemo, useState } from "react";
import type { Product } from "@/db/schema";
import ProductCard from "./ProductCard";

type Tab = "all" | "chocolate" | "hamper";

const TABS: { key: Tab; label: string }[] = [
  { key: "all", label: "All Chocolates" },
  { key: "chocolate", label: "Famous Brands" },
  { key: "hamper", label: "Gift Hampers" },
];

export default function ProductGrid({ products }: { products: Product[] }) {
  const [tab, setTab] = useState<Tab>("all");
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    let list = products;
    if (tab === "chocolate") list = list.filter((p) => p.category === "chocolate");
    if (tab === "hamper") list = list.filter((p) => p.category === "hamper");
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.brand.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q)
      );
    }
    return list;
  }, [tab, query, products]);

  return (
    <section>
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap gap-2">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`rounded-full px-4 py-2 text-sm font-semibold transition-colors ${
                tab === t.key
                  ? "bg-amber-700 text-white"
                  : "bg-white text-stone-700 ring-1 ring-stone-200 hover:bg-stone-100"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search chocolate…"
          className="w-full rounded-full border border-stone-300 bg-white px-4 py-2 text-sm outline-none focus:border-amber-500 sm:w-64"
        />
      </div>

      {filtered.length === 0 ? (
        <p className="py-16 text-center text-stone-500">
          No chocolates found. Try a different search.
        </p>
      ) : (
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filtered.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </section>
  );
}

import "dotenv/config";
import { db } from "@/db";
import { products } from "@/db/schema";
import { count } from "drizzle-orm";

type SeedProduct = {
  name: string;
  brand: string;
  category: "chocolate" | "hamper";
  description: string;
  priceCents: number;
  image: string;
  stock: number;
  featured: boolean;
  country: string;
};

const img = {
  truffleBox:
    "https://images.pexels.com/photos/38444667/pexels-photo-38444667.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  colorfulRibbon:
    "https://images.pexels.com/photos/6487798/pexels-photo-6487798.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  pralinesBoard:
    "https://images.pexels.com/photos/18354706/pexels-photo-18354706.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  plateChocs:
    "https://images.pexels.com/photos/9279002/pexels-photo-9279002.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  glossyTruffle:
    "https://images.pexels.com/photos/8627518/pexels-photo-8627518.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  barsWhite:
    "https://images.pexels.com/photos/8794102/pexels-photo-8794102.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  barsDark:
    "https://images.pexels.com/photos/32402905/pexels-photo-32402905.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  barsFlat:
    "https://images.pexels.com/photos/4113305/pexels-photo-4113305.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  barsFlowers:
    "https://images.pexels.com/photos/14750356/pexels-photo-14750356.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  hamperBasket:
    "https://images.pexels.com/photos/20699854/pexels-photo-20699854.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  hamperLux:
    "https://images.pexels.com/photos/20699855/pexels-photo-20699855.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  hamperBox:
    "https://images.pexels.com/photos/28769885/pexels-photo-28769885.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  hamperCeleb:
    "https://images.pexels.com/photos/6487761/pexels-photo-6487761.png?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
};

const seedProducts: SeedProduct[] = [
  // ---- Famous worldwide chocolate brands ----
  {
    name: "Lindt Lindor Truffles 200g",
    brand: "Lindt",
    category: "chocolate",
    description:
      "The iconic Swiss truffle with a velvety smooth centre that melts the moment it touches your tongue. Mastered by Lindt's Maîtres Chocolatiers.",
    priceCents: 1899,
    image: img.truffleBox,
    stock: 120,
    featured: true,
    country: "Switzerland",
  },
  {
    name: "Ferrero Rocher Gold Collection",
    brand: "Ferrero Rocher",
    category: "chocolate",
    description:
      "Golden roasted hazelnuts wrapped in rich milk chocolate with a crunchy wafer layer. Italy's most loved gifting chocolate.",
    priceCents: 2499,
    image: img.colorfulRibbon,
    stock: 150,
    featured: true,
    country: "Italy",
  },
  {
    name: "Godiva Signature Truffles Box",
    brand: "Godiva",
    category: "chocolate",
    description:
      "A Belgian masterpiece of handcrafted truffles and pralines, each piece a journey through silky ganache and fine cocoa.",
    priceCents: 3999,
    image: img.pralinesBoard,
    stock: 80,
    featured: true,
    country: "Belgium",
  },
  {
    name: "Toblerone Swiss Milk Chocolate",
    brand: "Toblerone",
    category: "chocolate",
    description:
      "The world-famous triangular Swiss bar with honey and almond nougat. A true icon of the Alps since 1908.",
    priceCents: 1099,
    image: img.barsWhite,
    stock: 200,
    featured: false,
    country: "Switzerland",
  },
  {
    name: "Ghirardelli Intense Dark Squares",
    brand: "Ghirardelli",
    category: "chocolate",
    description:
      "San Francisco's celebrated premium dark chocolate squares, rich and velvety with notes of ripe berries and cocoa.",
    priceCents: 1499,
    image: img.barsDark,
    stock: 180,
    featured: false,
    country: "USA",
  },
  {
    name: "Cadbury Dairy Milk Bar",
    brand: "Cadbury",
    category: "chocolate",
    description:
      "The classic British glass-and-a-half bar of creamy, delicious milk chocolate loved around the world.",
    priceCents: 799,
    image: img.barsFlat,
    stock: 250,
    featured: false,
    country: "United Kingdom",
  },
  {
    name: "Milka Alpine Milk Chocolate",
    brand: "Milka",
    category: "chocolate",
    description:
      "Tender Alpine milk chocolate made with Alpine milk, famously creamy and wrapped in lilac since 1901.",
    priceCents: 899,
    image: img.barsFlowers,
    stock: 220,
    featured: false,
    country: "Germany",
  },
  {
    name: "Valrhona Grand Cru Dark Bar",
    brand: "Valrhona",
    category: "chocolate",
    description:
      "A French grand cru dark chocolate bar crafted from single-origin cacao, prized by the world's finest pastry chefs.",
    priceCents: 2199,
    image: img.barsDark,
    stock: 90,
    featured: false,
    country: "France",
  },
  {
    name: "Guylian Belgian Seashells",
    brand: "Guylian",
    category: "chocolate",
    description:
      "Handmade Belgian seashell-shaped chocolates with a delicate hazelnut praliné filling, famous since 1960.",
    priceCents: 1699,
    image: img.plateChocs,
    stock: 130,
    featured: false,
    country: "Belgium",
  },
  {
    name: "Royce' Nama Chocolate",
    brand: "Royce'",
    category: "chocolate",
    description:
      "Japan's ultra-smooth nama chocolate from Hokkaido, melt-in-the-mouth pieces dusted with pure cocoa.",
    priceCents: 3299,
    image: img.glossyTruffle,
    stock: 70,
    featured: false,
    country: "Japan",
  },
  {
    name: "Hershey's Kisses Milk Chocolates",
    brand: "Hershey's",
    category: "chocolate",
    description:
      "The timeless American classic — bite-sized milk chocolate kisses that everyone recognises on sight.",
    priceCents: 699,
    image: img.barsFlat,
    stock: 300,
    featured: false,
    country: "USA",
  },
  {
    name: "Nestlé KitKat Chunky",
    brand: "Nestlé",
    category: "chocolate",
    description:
      "Crisp wafer fingers enrobed in rich milk chocolate. Take a break with the world's favourite chocolate biscuit.",
    priceCents: 899,
    image: img.barsWhite,
    stock: 260,
    featured: false,
    country: "United Kingdom",
  },
  {
    name: "Moser Roth Finest Dark",
    brand: "Moser Roth",
    category: "chocolate",
    description:
      "German craft chocolate in a sleek double-pack, intense single-origin bars for the discerning connoisseur.",
    priceCents: 1299,
    image: img.barsDark,
    stock: 110,
    featured: false,
    country: "Germany",
  },
  {
    name: "See's Candies Milk Truffle",
    brand: "See's Candies",
    category: "chocolate",
    description:
      "A beloved American West Coast confectionery house, famous for its silky milk chocolate truffles.",
    priceCents: 1999,
    image: img.truffleBox,
    stock: 95,
    featured: false,
    country: "USA",
  },
  // ---- Gift hampers ----
  {
    name: "Grand Chocolate Gift Basket",
    brand: "ChocoLuxe",
    category: "hamper",
    description:
      "A generously packed wicker basket bursting with pralines, truffles and artisan sweets — the ultimate chocolate lover's hamper.",
    priceCents: 5999,
    image: img.hamperBasket,
    stock: 40,
    featured: true,
    country: "Premium Blend",
  },
  {
    name: "Celebration Luxury Hamper",
    brand: "ChocoLuxe",
    category: "hamper",
    description:
      "Champagne, chocolates and gourmet treats presented in an elegant box. Perfect for birthdays, anniversaries and weddings.",
    priceCents: 7499,
    image: img.hamperCeleb,
    stock: 35,
    featured: true,
    country: "Premium Blend",
  },
  {
    name: "Belgian Praline Deluxe Box",
    brand: "ChocoLuxe",
    category: "hamper",
    description:
      "A curated selection of fine Belgian pralines, truffles and hand-dipped chocolates in a keepsake presentation box.",
    priceCents: 4599,
    image: img.hamperLux,
    stock: 50,
    featured: false,
    country: "Belgium",
  },
  {
    name: "Sweet Celebrations Hamper",
    brand: "ChocoLuxe",
    category: "hamper",
    description:
      "An assortment of cookies, chocolates and festive sweets beautifully arranged for any celebration or thank-you gift.",
    priceCents: 3999,
    image: img.hamperBox,
    stock: 60,
    featured: false,
    country: "Premium Blend",
  },
];

export async function seedDatabase() {
  const existing = await db.select({ n: count() }).from(products);
  const total = existing[0]?.n ?? 0;

  if (total === 0) {
    const rows = seedProducts.map((p) => ({ ...p }));
    for (const row of rows) {
      await db.insert(products).values(row);
    }
    console.log(`Seeded ${rows.length} products.`);
  } else {
    console.log(`Products already present (${total}). Skipping seed.`);
  }
}

if (process.argv[1]?.includes("seed")) {
  seedDatabase()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error(err);
      process.exit(1);
    });
}

export type CartItem = {
  productId: number;
  name: string;
  brand: string;
  priceCents: number;
  image: string;
  quantity: number;
};

export const CART_STORAGE_KEY = "choc_cart";

export function cartSubtotal(items: CartItem[]): number {
  return items.reduce((sum, i) => sum + i.priceCents * i.quantity, 0);
}

export function cartCount(items: CartItem[]): number {
  return items.reduce((sum, i) => sum + i.quantity, 0);
}

export function formatCents(cents: number): string {
  return (cents / 100).toLocaleString("en-US", {
    style: "currency",
    currency: "USD",
  });
}
